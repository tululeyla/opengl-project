
#include<gl/glut.h>
#include<math.h>
#include<MMSystem.h>
#include<windows.h>
GLfloat move_x=0.0,mov_man=0.0,moveAfter_x=0.0,house_move=0.0,move_y;
float d;
	void egats()
	{

	glClearColor(0.2,0.45,0.78,0.4);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

    gluOrtho2D(0,0,0,0); 
		}
	
void CALL(){
	
		glPushMatrix();
	//BACK TREE 4
	glColor3f(1.0,1.0,0.0);
	glLineWidth(2);
	glBegin(GL_LINES);
	glVertex2f(0.8,-0.28);
	glVertex2f(0.8,0.06);
	glEnd();
	glPopMatrix();
	
	
	
		//tree 4.1
	
	glPushMatrix();
	glColor3f(0.0,0.8,0.0);
	glBegin(GL_TRIANGLES);
    glVertex2f(0.74,-0.09);
	glVertex2f(0.85,-0.09);
	glVertex2f(0.79,0.15);
	glEnd();
	glPopMatrix();
		//tree 4.2
	
	glPushMatrix();
	glColor3f(0.0,0.8,0.0);
	glBegin(GL_TRIANGLES);
    glVertex2f(0.74,-0.12);
	glVertex2f(0.85,-0.12);
	glVertex2f(0.79,0.0);
	glEnd();
	glPopMatrix();
	
		glPushMatrix();
	//cars ASPALTE 
	glColor3f(0.3,0.3,0.3);
	glBegin(GL_QUADS);
	glVertex2f(-1,-0.8);
	glVertex2f(1,-0.8);
	glVertex2f(1,-0.4);
	glVertex2f(-1,-0.4);
	glEnd();
	glPopMatrix();
	
		glPushMatrix();
	//aspalte 1
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.99,-0.62);
	glVertex2f(-0.9,-0.62);
	glVertex2f(-0.9,-0.6);
	glVertex2f(-0.99,-0.6);
	glEnd();
	glPopMatrix();
	
		glPushMatrix();
	//aspalte 2
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.8,-0.62);
	glVertex2f(-0.7,-0.62);
	glVertex2f(-0.7,-0.6);
	glVertex2f(-0.8,-0.6);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//aspalte 3
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.6,-0.62);
	glVertex2f(-0.5,-0.62);
	glVertex2f(-0.5,-0.6);
	glVertex2f(-0.6,-0.6);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//aspalte 3
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.6,-0.62);
	glVertex2f(-0.5,-0.62);
	glVertex2f(-0.5,-0.6);
	glVertex2f(-0.6,-0.6);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//aspalte 4
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.4,-0.62);
	glVertex2f(-0.3,-0.62);
	glVertex2f(-0.3,-0.6);
	glVertex2f(-0.4,-0.6);
	glEnd();
	glPopMatrix();
	
		glPushMatrix();
	//aspalte 5 for +ve
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.4,-0.62);
	glVertex2f(0.3,-0.62);
	glVertex2f(0.3,-0.6);
	glVertex2f(0.4,-0.6);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//aspalte 6 for +ve
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.6,-0.62);
	glVertex2f(0.5,-0.62);
	glVertex2f(0.5,-0.6);
	glVertex2f(0.6,-0.6);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//aspalte 7 for +ve
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.8,-0.62);
	glVertex2f(0.7,-0.62);
	glVertex2f(0.7,-0.6);
	glVertex2f(0.8,-0.6);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//aspalte 8 for +ve
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.9,-0.62);
	glVertex2f(1.0,-0.62);
	glVertex2f(1.0,-0.6);
	glVertex2f(0.9,-0.6);
	glEnd();
	glPopMatrix();
		glPushMatrix();
		
		//last QUAD
	glColor3f(0.2,0.6,0.2);
	glBegin(GL_QUADS);
	glVertex2f(-1,-2);
	glVertex2f(1,-2);
	glVertex2f(1,-0.8);
	glVertex2f(-1,-0.8);
	glEnd();
	glPopMatrix();
	
		glPushMatrix();
	//START MAN 
	glColor3f(0.3,0.3,0.3);
	glBegin(GL_QUADS);
	glVertex2f(-0.2,-0.8);
	glVertex2f(0.2,-0.8);
	glVertex2f(0.2,-0.999);
	glVertex2f(-0.2,-0.999);
	glEnd();
	
	glPopMatrix();
	
		glPushMatrix();
//zebra 1
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.1,-0.99);
	glVertex2f(0.1,-0.99);
	glVertex2f(0.1,-0.95);
	glVertex2f(-0.1,-0.95);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//zebra 2
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.1,-0.9);
	glVertex2f(0.1,-0.9);
	glVertex2f(0.1,-0.85);
	glVertex2f(-0.1,-0.85);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//zebra 3
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.1,-0.8);
	glVertex2f(0.1,-0.8);
	glVertex2f(0.1,-0.75);
	glVertex2f(-0.1,-0.75);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//zebra 4
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.1,-0.7);
	glVertex2f(0.1,-0.7);
	glVertex2f(0.1,-0.65);
	glVertex2f(-0.1,-0.65);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//zebra 5
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.1,-0.6);
	glVertex2f(0.1,-0.6);
	glVertex2f(0.1,-0.55);
	glVertex2f(-0.1,-0.55);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//zebra 6
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.1,-0.5);
	glVertex2f(0.1,-0.5);
	glVertex2f(0.1,-0.45);
	glVertex2f(-0.1,-0.45);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	//zebra 7
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.1,-0.4);
	glVertex2f(0.1,-0.4);
	glVertex2f(0.1,-0.35);
	glVertex2f(-0.1,-0.35);
	glEnd();
	glPopMatrix();
	
   // CARS1////////////////////////////////////////////////////////car

	glPushMatrix();
glColor3f(1.0,0.0,0.0);
   glBegin(GL_QUADS);
   glVertex2f(0.72-move_x-moveAfter_x,-0.56);
   glVertex2f(0.96-move_x-moveAfter_x,-0.56);
   glVertex2f(0.92-move_x-moveAfter_x,-0.47);
   glVertex2f(0.8-move_x-moveAfter_x,-0.47);
 glEnd();
 glPopMatrix();
 	glPushMatrix();
   glColor3f(1.0,0.0,0.0);
   glBegin(GL_QUADS);
   glVertex2f(0.68-move_x-moveAfter_x,-0.66);
   glVertex2f(0.96-move_x-moveAfter_x,-0.66);
   glVertex2f(0.96-move_x-moveAfter_x,-0.55);
   glVertex2f(0.68-move_x-moveAfter_x,-0.56);
   glEnd();
   glPopMatrix();
   //TIRE
   	glPushMatrix();
   glColor3f(0.0,0.0,0.0);
    // glLineWidth(6);

    glBegin(GL_POLYGON);
    float f;
    for (double i=0; i<360; i++)
    {
    	f=i*3.142/180;
    	glVertex2f((0.72-move_x-moveAfter_x)+0.02*cos(f),-0.67+0.04*sin(f));   //0.72+0.02*cos(d),-0.67+0.02*sin(d)
	}
	glEnd();
	
	glPopMatrix();
	glPushMatrix();
	glColor3f(0.0,0.0,0.0);
    glBegin(GL_POLYGON);
    float d;
    for (double i=0; i<360; i++)
    {
    	d=i*3.142/180;
    	glVertex2f((0.92-move_x-moveAfter_x)+0.02*cos(d),-0.67+0.04*sin(d));
	}
	glEnd();
	glPopMatrix();
	
	 // CARS 2////////////////////////////////////////////////////////car

	glPushMatrix();
	glPushMatrix();
glColor3f(0.0,0.0,0.0);
   glBegin(GL_QUADS);
   glVertex2f(-0.25-move_y,-0.56);
   glVertex2f(-0.66-move_y,-0.56);
   glVertex2f(-0.5-move_y,-0.47);
   glVertex2f(-0.25-move_y,-0.47);
 glEnd();
 
 	glPushMatrix();
   glColor3f(1.0,0.9,1.0);
   glBegin(GL_QUADS);
   glVertex2f(-0.25-move_y,-0.66);
   glVertex2f(-0.66-move_y,-0.66);
   glVertex2f(-0.66-move_y,-0.56);
   glVertex2f(-0.25-move_y,-0.56);
   glEnd();
   	glPushMatrix();
	glColor3f(0.0,0.0,0.0);
    glBegin(GL_POLYGON);
    float E;
    for (double i=0; i<360; i++)
    {
    	E=i*3.142/180;
    	glVertex2f((-0.35-move_y)+0.02*cos(E),-0.66+0.04*sin(E));
	}
	glEnd();
	glPopMatrix();
		glPushMatrix();
	glColor3f(0.0,0.0,0.0);
    glBegin(GL_POLYGON);
    float G;
    for (double i=0; i<360; i++)
    {
    	G=i*3.142/180;
    	glVertex2f((-0.56-move_y)+0.02*cos(G),-0.66+0.04*sin(G));
	}
	glEnd();
	glPopMatrix();
   
   
	
	//TIRE
	
	glColor3f(0.0,0.0,0.0);
    glBegin(GL_POLYGON);
    float h;
    for (double i=0; i<360; i++)
    {
    	h=i*3.142/180;
    	glVertex2f((0.92-move_x-moveAfter_x)+0.02*cos(h),-0.67+0.04*sin(h));
	}
	glEnd();
	
		


	//FIRST QUAD OR GRASS 1
	glPushMatrix();
	glColor3f(0.2,0.6,0.2);
	glBegin(GL_QUADS);
	glVertex2f(-1,-0.4);
	glVertex2f(1,-0.4);
	glVertex2f(1,-0.14);
	glVertex2f(-1,-0.14);
	glEnd();
	glPopMatrix();
	
	//block one 
	glPushMatrix();
	glColor3f(0.3,0.2,0.7);
	glBegin(GL_POLYGON);
	glVertex2f(-0.97,-0.14);
	glVertex2f(-0.7,-0.14);
	glVertex2f(-0.7,0.6);
	glVertex2f(-0.97,0.6);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	glColor3f(1.0,0.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.97,0.6);
	glVertex2f(-0.7,0.6);
	glVertex2f(-0.7,0.8);
	glVertex2f(-0.97,0.8);
	glEnd();
	glPopMatrix();
		//block 1.1
	glPushMatrix();
	glColor3f(0.0,0.0,0.2);
	glBegin(GL_POLYGON);
	glVertex2f(-0.7,-0.14);
	glVertex2f(-0.65,-0.14);
	glVertex2f(-0.65,0.7);
	glVertex2f(-0.7,0.8);
	glEnd();
	glPopMatrix();
	
	//BUILDING 
		glPushMatrix();
   glColor3f(0.0,1.0,1.0);

 float g;
    glBegin(GL_POLYGON);
    for (double i=0; i<360; i++)
    {
    	g=i*3.142/180;
    	glVertex2f((-0.84)+0.09*cos(g),0.7+0.09*sin(g));   //0.72+0.02*cos(d),-0.67+0.02*sin(d)
	}
	glEnd();
	glPopMatrix();
	
		///b1 door
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);

	glVertex2f(-0.87,-0.14);
	glVertex2f(-0.8,-0.14);
	glVertex2f(-0.8,0.07);
	glVertex2f(-0.87,0.07);
	glEnd();
		glPopMatrix();
	//window6
	glPushMatrix();
glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.95,0.13);
	glVertex2f(-0.86,0.13);
	glVertex2f(-0.86,0.23);
	glVertex2f(-0.95,0.23);
	glEnd();
	glPopMatrix();
	
	//window5
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.82,0.13);
	glVertex2f(-0.73, 0.13);
	glVertex2f(-0.73,0.23);
	glVertex2f(-0.82,0.23);
	glEnd();
		glPopMatrix();
	//window 4
	glPushMatrix();
glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.95, 0.3);
	glVertex2f(-0.86, 0.3);
	glVertex2f(-0.86,0.4);
	glVertex2f(-0.95,0.4);
	glEnd();
		glPopMatrix();
	//window3
	glPushMatrix();
glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.82,0.3);
	glVertex2f(-0.73, 0.3);
	glVertex2f(-0.73,0.4);
	glVertex2f(-0.82,0.4);
	glEnd();
	glPopMatrix();
		//window 2
	glPushMatrix();
glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.95, 0.46);
	glVertex2f(-0.86, 0.46);
	glVertex2f(-0.86,0.56);
	glVertex2f(-0.95,0.56);
	glEnd();
		glPopMatrix();
//window1
	glPushMatrix();
glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.82,0.46);
	glVertex2f(-0.73, 0.46);
	glVertex2f(-0.73,0.56);
	glVertex2f(-0.82,0.56);
	glEnd();
		glPopMatrix();
	
	
	//b 2
		glPushMatrix();
	glColor3f(0.2,0.0,0.2);
	glBegin(GL_POLYGON);
	glVertex2f(0.8,-0.14);
	glVertex2f(0.99,-0.14);
	glVertex2f(0.99,0.8);
	glVertex2f(0.8,0.8);
	glEnd();
	glPopMatrix();
	
	//s b 2.1
	
glPushMatrix();
	glColor3f(0.0,0.0,0.2);
	glBegin(GL_POLYGON);
	glVertex2f(0.75,-0.14);
	glVertex2f(0.8,-0.14);
	glVertex2f(0.8,0.8);
	glVertex2f(0.75,0.7);
	glEnd();
	glPopMatrix();
		//window2.1
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.82,0.5);
	glVertex2f(0.88, 0.5);
	glVertex2f(0.88,0.6);
	glVertex2f(0.82,0.6);
	glEnd();
	glPopMatrix();
	//window 2.12
		glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.92,0.5);
	glVertex2f(0.98, 0.5);
	glVertex2f(0.98,0.6);
	glVertex2f(0.92,0.6);
	glEnd();
	glPopMatrix();
	//window2.13
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.82,0.4);
	glVertex2f(0.88, 0.4);
	glVertex2f(0.88,0.3);
	glVertex2f(0.82,0.3);
	glEnd();
	glPopMatrix();
	//window 2.14
		glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.92,0.4);
	glVertex2f(0.98, 0.4);
	glVertex2f(0.98,0.3);
	glVertex2f(0.92,0.3);
	glEnd();
		glPopMatrix();
	//window 2.15
		glPushMatrix();
		glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.82,0.2);
	glVertex2f(0.88, 0.2);
	glVertex2f(0.88,0.1);
	glVertex2f(0.82,0.1);
	glEnd();
		glPopMatrix();
	//window 2.16
		glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.92,0.2);
	glVertex2f(0.98, 0.2);
	glVertex2f(0.98,0.1);
	glVertex2f(0.92,0.1);
	glEnd();
		glPopMatrix();
	//door 2.16
		glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.92,0.0);
	glVertex2f(0.87, 0.0);
	glVertex2f(0.87,-0.14);
	glVertex2f(0.92,-0.14);
	glEnd();
	
	glPopMatrix();

	//b3
		glPushMatrix();
	glColor3f(1.0,0.0,0.2);
	glBegin(GL_POLYGON);
	glVertex2f(-0.63,-0.14);
	glVertex2f(-0.35,-0.14);
	glVertex2f(-0.35,0.47);
	glVertex2f(-0.49,0.56);
	glVertex2f(-0.63,0.47);
	glEnd();
	glPopMatrix();
	//b4
		glPushMatrix();
	glColor3f(1.0,0.0,1.2);
	glBegin(GL_POLYGON);
	glVertex2f(-0.33,-0.14);
	glVertex2f(-0.18,-0.14);
	glVertex2f(-0.18,0.65);
	glVertex2f(-0.33,0.65);
	glEnd();
	glPopMatrix();
	//b4.1
		glPushMatrix();
	glColor3f(0.0,0.0,0.2);
	glBegin(GL_POLYGON);
	glVertex2f(-0.18,-0.14);
	glVertex2f(-0.15,-0.14);
	glVertex2f(-0.15,0.55);
	glVertex2f(-0.18,0.65);
	glEnd();
	glPopMatrix();
	//MOON
	glColor3f(1.0,1.0,0.0);
		glPushMatrix();
	 glBegin(GL_TRIANGLE_FAN);
    for (double i=0; i<360; i++)
    {
    	d=i*3.142/180;
    	glVertex2f(0.0+0.09*cos(d),0.0+mov_man+0.09*sin(d));
	}
	glEnd();
	glPopMatrix();
	//b5.1
	glPushMatrix();
	glColor3f(0.0,0.0,0.0);
	glBegin(GL_POLYGON);
	glVertex2f(-0.10,-0.14);
	glVertex2f(-0.05,-0.14);
	glVertex2f(-0.05,0.35);
	glVertex2f(-0.10,0.28);
	glEnd();
	glPopMatrix();
	
	//b5 
	glPushMatrix();
	glColor3f(0.4,0.0,0.05);
	glBegin(GL_POLYGON);
	glVertex2f(-0.05,-0.14);
	glVertex2f(0.2,-0.14);
	glVertex2f(0.2,0.35);
	glVertex2f(-0.05,0.35);
	glEnd();
	glPopMatrix();
	//b5 door
	glPushMatrix();
	glColor3f(0.0,0.0,0.0);
	glBegin(GL_POLYGON);
	glVertex2f(0.1,-0.14);
	glVertex2f(0.2,-0.14);
	glVertex2f(0.2,0.15);
	glVertex2f(0.1,0.06);
	glEnd();
	glPopMatrix();
//b6
		glPushMatrix();
	glColor3f(0.8,0.8,0.2);
	glBegin(GL_POLYGON);
	glVertex2f(0.25,-0.14);
	glVertex2f(0.45,-0.14);
	glVertex2f(0.45,0.65);
	glVertex2f(0.25,0.65);
	glEnd();
	glPopMatrix();
	//b6.1
		glPushMatrix();
	glColor3f(0.0,0.0,0.2);
	glBegin(GL_POLYGON);
	glVertex2f(0.22,-0.14);
	glVertex2f(0.25,-0.14);
	glVertex2f(0.25,0.65);
	glVertex2f(0.22,0.57);
	glEnd();
	glPopMatrix();
	//b7
		glPushMatrix();
	glColor3f(0.8,0.8,0.2);
	glBegin(GL_POLYGON);
	glVertex2f(0.51,-0.14);
	glVertex2f(0.70,-0.14);
	glVertex2f(0.70,0.3);
	glVertex2f(0.51,0.3);
	glEnd();
	glPopMatrix();
	//b7.1
		glPushMatrix();
	glColor3f(0.0,0.0,0.2);
	glBegin(GL_POLYGON);
	glVertex2f(0.48,-0.14);
	glVertex2f(0.51,-0.14);
	glVertex2f(0.51,0.3);
	glVertex2f(0.48,0.25);
	glEnd();
	glPopMatrix();
	
	
		//b4 window2.1
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.25,0.54);
	glVertex2f(-0.20, 0.54);
	glVertex2f(-0.20,0.62);
	glVertex2f(-0.25,0.62);
	glEnd();
		glPopMatrix();
			//b4 window2.2
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.32,0.54);
	glVertex2f(-0.27, 0.54);
	glVertex2f(-0.27,0.62);
	glVertex2f(-0.32,0.62);
	glEnd();
		glPopMatrix();
		
		//b4 window2.3
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.25,0.48);
	glVertex2f(-0.20, 0.48);
	glVertex2f(-0.20,0.4);
	glVertex2f(-0.25,0.4);
	glEnd();
		glPopMatrix();
			//b4 window2.4
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.32,0.48);
	glVertex2f(-0.27, 0.48);
	glVertex2f(-0.27,0.4);
	glVertex2f(-0.32,0.4);
	glEnd();
		glPopMatrix();
		//b4 window2.5
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.25,0.34);
	glVertex2f(-0.20, 0.34);
	glVertex2f(-0.20,0.26);
	glVertex2f(-0.25,0.26);
	glEnd();
		glPopMatrix();
			//b4 window2.6
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.32,0.34);
	glVertex2f(-0.27, 0.34);
	glVertex2f(-0.27,0.26);
	glVertex2f(-0.32,0.26);
	glEnd();
		glPopMatrix();
			//b4 window2.7
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.25,0.2);
	glVertex2f(-0.20, 0.2);
	glVertex2f(-0.20,0.12);
	glVertex2f(-0.25,0.12);
	glEnd();
		glPopMatrix();
			//b4 window2.8
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.32,0.2);
	glVertex2f(-0.27, 0.2);
	glVertex2f(-0.27,0.12);
	glVertex2f(-0.32,0.12);
	glEnd();
		glPopMatrix();
			//b3 window3.1
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.6,0.25);
	glVertex2f(-0.52,0.25);
	glVertex2f(-0.52,0.37);
	glVertex2f(-0.6,0.37);
	glEnd();
		glPopMatrix();
				//b3 window3.2
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.48,0.25);
	glVertex2f(-0.4,0.25);
	glVertex2f(-0.4,0.37);
	glVertex2f(-0.48,0.37);
	glEnd();
			glPopMatrix();
			//b3 window3.3
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.6,0.05);
	glVertex2f(-0.52,0.05);
	glVertex2f(-0.52,0.17);
	glVertex2f(-0.6,0.17);
	glEnd();
		glPopMatrix();
				//b3 window3.4
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.48,0.05);
	glVertex2f(-0.4,0.05);
	glVertex2f(-0.4,0.17);
	glVertex2f(-0.48,0.17);
	glEnd();
		glPopMatrix();
		//b6 window3.1
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.27,0.5);
	glVertex2f(0.33,0.5);
	glVertex2f(0.33,0.6);
	glVertex2f(0.27,0.6);
	glEnd();
		glPopMatrix();
			//b6 window3.2
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.37,0.5);
	glVertex2f(0.43,0.5);
	glVertex2f(0.43,0.6);
	glVertex2f(0.37,0.6);
	glEnd();
		glPopMatrix();
		//b6 window3.3
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.27,0.3);
	glVertex2f(0.33,0.3);
	glVertex2f(0.33,0.4);
	glVertex2f(0.27,0.4);
	glEnd();
		glPopMatrix();
			//b6 window3.4
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.37,0.3);
	glVertex2f(0.43,0.3);
	glVertex2f(0.43,0.4);
	glVertex2f(0.37,0.4);
	glEnd();
		glPopMatrix();
	
		//b6 window3.5
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.27,0.1);
	glVertex2f(0.33,0.1);
	glVertex2f(0.33,0.2);
	glVertex2f(0.27,0.2);
	glEnd();
		glPopMatrix();
			//b6 window3.6
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.37,0.1);
	glVertex2f(0.43,0.1);
	glVertex2f(0.43,0.2);
	glVertex2f(0.37,0.2);
	glEnd();
		glPopMatrix();
		//b7 window3.1
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.62,0.18);
	glVertex2f(0.68,0.18);
	glVertex2f(0.68,0.27);
	glVertex2f(0.62,0.27);
	glEnd();
		glPopMatrix();
	//b7 window3.2
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.52,0.18);
	glVertex2f(0.58,0.18);
	glVertex2f(0.58,0.27);
	glVertex2f(0.52,0.27);
	glEnd();
		glPopMatrix();
		//b7 window3.3
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.62,0.05);
	glVertex2f(0.68,0.05);
	glVertex2f(0.68,0.14);
	glVertex2f(0.62,0.14);
	glEnd();
		glPopMatrix();
	//b7 window3.4
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.52,0.05);
	glVertex2f(0.58,0.05);
	glVertex2f(0.58,0.14);
	glVertex2f(0.52,0.14);
	glEnd();
		glPopMatrix();
			//b7 door
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.57,0.0);
	glVertex2f(0.63,0.0);
	glVertex2f(0.63,-0.14);
	glVertex2f(0.57,-0.14);
	glEnd();
		glPopMatrix();
			//b6 door
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(0.32,0.0);
	glVertex2f(0.38,0.0);
	glVertex2f(0.38,-0.14);
	glVertex2f(0.32,-0.14);
	glEnd();
		glPopMatrix();
				//b3 door
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.52,0.0);
	glVertex2f(-0.44,0.0);
	glVertex2f(-0.44,-0.14);
	glVertex2f(-0.52,-0.14);
	glEnd();
		glPopMatrix();
			//b4 door
	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex2f(-0.23,0.03);
	glVertex2f(-0.28, 0.03);
	glVertex2f(-0.28,-0.14);
	glVertex2f(-0.23,-0.14);
	glEnd();
	glPopMatrix();

  
	//line 1 tree 1
		glPushMatrix();
	glColor3f(1.0,1.0,0.0);
	glLineWidth(2);
	glBegin(GL_LINES);
	glVertex2f(-0.7,-0.28);
	glVertex2f(-0.7,0.06);
	glEnd();
	glPopMatrix();
	
	glPushMatrix();
	glColor3f(0.2,0.8,0.0);
	glBegin(GL_TRIANGLES);
    glVertex2f(-0.75,-0.12);
	glVertex2f(-0.65,-0.12);
	glVertex2f(-0.7,0.0);
	glEnd(); 
		glPopMatrix();
			//tree 1.2
	
	glPushMatrix();
	glColor3f(0.2,0.8,0.0);
	glBegin(GL_TRIANGLES);
    glVertex2f(-0.75,-0.07);
	glVertex2f(-0.65,-0.07);
	glVertex2f(-0.7,0.15);
	glEnd();
		glPopMatrix();
	
	
	
	//line 1 tree 2
	
	
		glPushMatrix();
	glColor3f(1.0,1.0,0.0);
	glLineWidth(2);
	glBegin(GL_LINES);
	glVertex2f(-0.4,-0.28);
	glVertex2f(-0.4,0.01);
	glEnd();
	glPopMatrix();
	//tree 2.1
	
	glPushMatrix();
	glColor3f(0.2,0.8,0.0);
	glBegin(GL_TRIANGLES);
    glVertex2f(-0.46,-0.12);
	glVertex2f(-0.35,-0.12);
	glVertex2f(-0.4,0.0);
	glEnd(); 
		glPopMatrix();
		//tree 2.2
	
	glPushMatrix();
	glColor3f(0.2,0.8,0.0);
	glBegin(GL_TRIANGLES);
    glVertex2f(-0.46,-0.07);
	glVertex2f(-0.35,-0.07);
	glVertex2f(-0.4,0.15);
	glEnd();
	glPopMatrix();
	
	//tree 3
		glPushMatrix();
	glColor3f(1.0,1.0,0.0);
	glLineWidth(2);
	glBegin(GL_LINES);
	glVertex2f(0.4,-0.28);
	glVertex2f(0.4,0.06);
	glEnd();
	glPopMatrix();
		
	
	//tree 3.1
	
	glPushMatrix();
	glColor3f(0.2,0.8,0.0);
	glBegin(GL_TRIANGLES);
    glVertex2f(0.35,-0.07);
	glVertex2f(0.45,-0.07);
	glVertex2f(0.4,0.15);
	glEnd();
	glPopMatrix();
	//tree 3.2
	
	glPushMatrix();
	glColor3f(0.2,0.8,0.0);
	glBegin(GL_TRIANGLES);
    glVertex2f(0.35,-0.12);
	glVertex2f(0.45,-0.12);
	glVertex2f(0.4,0.0);
	glEnd();
		glPopMatrix();
		
	//MAN STOP
	glPushMatrix();
	glColor3f(0.3,0.3,0.3);
	glBegin(GL_QUADS);
	glVertex2f(-0.2,-0.4);
	glVertex2f(0.2,-0.4);
	glVertex2f(0.2,-0.32);
	glVertex2f(-0.2,-0.32);
	glEnd();
	glPopMatrix();
	
	//man
		glPushMatrix();
   glColor3f(1.0,1.0,0.0);
   glBegin(GL_QUADS);
   	glVertex2f(-0.04,-0.9+mov_man);
	glVertex2f(0.009,-0.9+mov_man);
	glVertex2f(0.009,-0.96+mov_man);
	glVertex2f(-0.04,-0.96+mov_man);
	glEnd();
	glPopMatrix();
	glPushMatrix();
	glColor3f(0.8,1.0,0.0);
	glLineWidth(6);
	glBegin(GL_LINES);
	glVertex2f(-0.015,-0.9+mov_man);
	glVertex2f(-0.015,-0.86+mov_man);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	glColor3f(0.0,0.0,0.0);
    glBegin(GL_POLYGON);
    float K;
    for (double i=0; i<360; i++)
    {
    	K=i*3.142/180;
    	glVertex2f((-0.013)+0.02*cos(K),-0.86+mov_man+0.02*sin(K));
	}
	glEnd();
	
	glPopMatrix();

	//man LEG
		glPushMatrix();
	
	glColor3f(0.8,1.0,0.0);
	glLineWidth(6);
	glBegin(GL_LINES);
	glVertex2f(-0.023,-0.96+mov_man);
	glVertex2f(-0.023,-0.99+mov_man);
	glVertex2f(-0.01,-0.96+mov_man);
	glVertex2f(-0.01,-0.99+mov_man);
	glEnd();
	glPopMatrix();
	glPushMatrix();
	
	//man nacke
	glColor3f(0.8,1.0,0.0);
	glLineWidth(6);
	glBegin(GL_LINES);
	glVertex2f(-0.015,-0.9+mov_man);
	glVertex2f(-0.015,-0.86+mov_man);
	glEnd();
	glPopMatrix();
		glPushMatrix();
	glColor3f(1.0,1.0,0.0);
    glBegin(GL_POLYGON);
    float m;
    for (double i=0; i<360; i++)
    {
    	m=i*3.142/180;
    	glVertex2f((-0.013)+0.02*cos(m),-0.86+mov_man+0.02*sin(m));
	}
	glEnd();
	
	glPopMatrix();
		glPushMatrix();
	glColor3f(0.0,0.0,0.0);
    glBegin(GL_POLYGON);
    float V;
    for (double i=0; i<360; i++)
    {
    	V=i*3.142/180;
    	glVertex2f((-0.013)+0.023*cos(V),-0.84+mov_man+0.023*sin(V));
	}
	glEnd();

	
	glPopMatrix();
	
}

void clall2(){
	glPushMatrix();
	glTranslatef(-2+house_move,0.1,0);
    CALL();
 glPopMatrix();
	
}

		//BACKWARD LOOP
void move_call()
{  glPushMatrix();
	glTranslatef(house_move,0.1,1.0);
  CALL();
	glPopMatrix();
}

void display()
{
				
	//BACKGROUND ALL TO DONE OR PUT ALL COMPONENTES 
	glPushMatrix();
	glColor3f(0.2,0.45,0.78);
	glBegin(GL_POLYGON);
    glVertex2f(-1,1);
	glVertex2f(-1,-1);
	glVertex2f(1.9,-1);
		glVertex2f(1.9,1);
	glEnd();
	glPopMatrix();
	
	 glPushMatrix();
	clall2();
 glPopMatrix();
	
	glPushMatrix();
	
 move_call();
 glPopMatrix();

 	glFlush();
 	//housE move increment,CAR 
 	house_move=house_move+0.0001;
	move_x=move_x+0.0007;
		move_y=move_y+0.0003;
	if(move_x>=0.5){
	move_x=0.5;
	mov_man=mov_man+0.0004;
}
if(mov_man>=0.78)
{
	//after the man passes the road
		moveAfter_x=moveAfter_x+0.001;
	mov_man=0.78;//to stop the man
}
//to redisplay the graphics
	glutPostRedisplay();
	glutSwapBuffers();
}



  int main(int argc, char** argv)
   {
   
   	glutInit(&argc,argv);
   	glutInitDisplayMode(GLUT_RGB);
   	glutInitWindowSize(1100,660);
   	glutInitWindowPosition(0,0);
   	glutCreateWindow("GRAPHICS");
   
          egats();
    
 	glutDisplayFunc(display);
   	
   PlaySound(TEXT("car.wav"),NULL,SND_ASYNC);
    PlaySound(TEXT("car2.wav"),NULL,SND_ASYNC);
   glutMainLoop();
   	  return 0;
   
	   }
